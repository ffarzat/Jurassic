// Copyright 2009 the Sputnik authors.  All rights reserved.
// This code is governed by the BSD license found in the LICENSE file.

/**
 * HexEscapeSequence :: x HexDigit is incorrect
 *
 * @path bestPractice/Sbp_7.8.4_A6.2_T1.js
 * @description HexDigit :: 1
 * @negative
 */

//CHECK#1
"\x1"

